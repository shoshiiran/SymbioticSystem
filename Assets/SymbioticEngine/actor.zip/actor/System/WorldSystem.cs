using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using System.Threading;
using Cysharp.Threading.Tasks;

public class WorldSystem : IInitInterface
{

    readonly HashSet<ActorSystem> _allActorSystems = new();
    readonly HashSet<IFixUpdateInterface> _allFixUpdateSystems = new();
    readonly HashSet<IUpdateInterface> _allUpdateSystems = new();
    readonly HashSet<ILateUpdateInterface> _allLateUpdateSystems = new();



    readonly SortedSet<ActorSystem> _actorSystems = new();
    readonly Dictionary<int, ActorBehaviour> _actorBehaviours = new();


    Task[] taskList;
    TaskFactory factory = new TaskFactory();

    public CancellationTokenSource cts = new CancellationTokenSource();

    int _milliseconds;

    bool _updateTask = true;


    public void SetFPS(int fps)
    {
        fps = Mathf.Clamp(fps, 30, 100);
        _milliseconds = 1000 / fps;
    }

    public ActorBehaviour GetActorBehaviour(GameObject gameObject)
    {
        _actorBehaviours.TryGetValue(gameObject.GetHashCode(), out var behaviour);
        return behaviour;
    }

    public void AddSystem(ActorSystem actorSystem)
    {
        // AddActorSystem(actorSystem);
        if (actorSystem is IUpdateInterface)
        {
            _allUpdateSystems.Add(actorSystem as IUpdateInterface);
        }
        if (actorSystem is IFixUpdateInterface)
        {
            _allFixUpdateSystems.Add(actorSystem as IFixUpdateInterface);

        }
        if (actorSystem is ILateUpdateInterface)
        {
            _allLateUpdateSystems.Add(actorSystem as ILateUpdateInterface);
        }
    }

    public void RemoveSystem(ActorSystem actorSystem)
    {
        // AddActorSystem(actorSystem);
        if (actorSystem is IUpdateInterface)
        {
            _allUpdateSystems.Remove(actorSystem as IUpdateInterface);

        }
        if (actorSystem is IFixUpdateInterface)
        {
            _allFixUpdateSystems.Remove(actorSystem as IFixUpdateInterface);

        }
        if (actorSystem is ILateUpdateInterface)
        {
            _allLateUpdateSystems.Remove(actorSystem as ILateUpdateInterface);
        }
    }



    private void AddActorSystem(ActorSystem actorSystem)
    {
        if (_allActorSystems.Add(actorSystem))
        {
            // AddBehaviours(actorSystem);

        }
        else
        {
#if UNITY_EDITOR
            Debug.LogError("Actors集合添加" + actorSystem.Actor.name + "失败,AcotrSystem Name:" + actorSystem.ToString());
#endif
        }
    }

    public void AddBehaviours(ActorBehaviour behaviour)
    {
        if (_actorBehaviours.TryAdd(behaviour.Actor.GetHashCode(), behaviour))
        {
#if UNITY_EDITOR
            Debug.Log("Actors集合添加" + behaviour.Actor.name + "成功,ActorBehaviour Name:" + behaviour.ToString());
#endif
        }
        else
        {
#if UNITY_EDITOR
            Debug.LogError("Actors集合添加" + behaviour.Actor.name + "失败,ActorBehaviour Name:" + behaviour.ToString());
#endif
        }
    }

    public void RemoveBehaviours(ActorBehaviour behaviour)
    {
        if (_actorBehaviours.Remove(behaviour.Actor.GetHashCode()))
        {
#if UNITY_EDITOR
            Debug.Log("Actors集合移除" + behaviour.Actor.name + "成功,ActorBehaviour Name:" + behaviour.ToString());
#endif
        }
        else
        {
#if UNITY_EDITOR
            Debug.LogError("Actors集合移除" + behaviour.Actor.name + "失败,ActorBehaviour Name:" + behaviour.ToString());
#endif
        }
    }


    public void Run()
    {

    }

    public void OnDestroy()
    {
        foreach (var sys in _allActorSystems)
        {
            sys.OnDestroy();
        }

        cts.Cancel();
    }

    public void OnPause()
    {
        foreach (var sys in _allActorSystems)
        {
            sys.OnPause();
        }
    }

    public void OnResume()
    {
        foreach (var sys in _allActorSystems)
        {
            sys.OnResume();
        }
    }

    public void OnStart()
    {

        // new Task(_ =>
        //     {
        //         Debug.Log("fps" + _milliseconds);
        //         while (!cts.IsCancellationRequested)
        //         {
        //             if (_updateTask)
        //             {
        //                 _updateTask = false;
        //                 RunActorSystem();
        //                 Debug.Log($"ThreadID_Task Start={Thread.CurrentThread.ManagedThreadId.ToString()}");

        //             }

        //             Thread.Sleep(5000);
        //         }
        //     }, cts.Token, TaskCreationOptions.LongRunning).Start();


        // UniTask.Run(async () =>
        //     {
        //         Debug.Log("fps" + _milliseconds);
        //         while (!cts.IsCancellationRequested)
        //         {
        //             if (_updateTask)
        //             {
        //                 _updateTask = false;

        //                 Debug.Log($"ThreadID_Task Start={Thread.CurrentThread.ManagedThreadId.ToString()}");

        //                 RunActorSystem();

        //                 // foreach (var sys in _allSystems)
        //                 // {
        //                 //     sys.OnUpdate();
        //                 // }
        //             }

        //             await UniTask.Delay(1000);
        //         }
        //     });

        Debug.Log("CPU核心数量:" + SystemInfo.processorCount);

        Debug.Log($"ThreadID_Mono={Thread.CurrentThread.ManagedThreadId.ToString()}");

        foreach (var sys in _allActorSystems)
        {
            Debug.Log("worldSysytem Onstart执行");
            sys.OnStart();
        }
    }
    public static async Task Method1()
    {
        await Task.Run(() =>
                {
                    for (int i = 0; i < 100; i++)
                    {
                    }
                });
    }


    //*Unitask版本
    private async UniTask RunActorSystem()
    {


        //UniTask.Run(Action, bool, CancellationToken)' is obsolete: 'UniTask.Run is similar as Task.Run, it uses ThreadPool. For equivalent behaviour, use UniTask.RunOnThreadPool instead. If you don't want to use ThreadPool, you can use UniTask.Void(async void) or UniTask.Create(async UniTask) too.' [Assembly-CSharp]csharp(CS0618)


        //todo 所有的actor 先init完成结束
        //todo 2 所有的actor 执行 update
        UniTask.Void(async () =>
        {
            // //todo actor 1.preupdate  ->2.update -->3.lateupdate
            Debug.Log($"ThreadID_Task1={Thread.CurrentThread.ManagedThreadId.ToString()}");
            // Thread.Sleep(1000);

            foreach (var sys in _allActorSystems)
            {
                // sys.OnUpdate();
            }
            _updateTask = true;
            await UniTask.Yield();
        });
        // var task2 = new Task(_ =>
        // {
        //     Debug.Log($"ThreadID_Task2={Thread.CurrentThread.ManagedThreadId.ToString()}");
        //     // Thread.Sleep(5000);
        // }, cts.Token);
        // task2.Start();

        // taskList = new Task[]{
        //     task1,
        //     task2,
        //     };


        // factory.ContinueWhenAll(taskList, _ =>
        //     {
        //         Debug.Log("子线程完毕" + System.DateTime.Now.Second);
        //         _updateTask = true;
        //     }, cts.Token);
    }


    //*task 版本
    // private void RunActorSystem()
    // {

    //     //todo 所有的actor 先init完成结束
    //     //todo 2 所有的actor 执行 update
    //     var task1 = new Task(t =>
    //     {
    //         //todo actor 1.preupdate  ->2.update -->3.lateupdate
    //         Debug.Log($"ThreadID_Task1={Thread.CurrentThread.ManagedThreadId.ToString()}");
    //         // Thread.Sleep(1000);

    //         foreach (var sys in _allSystems)
    //         {
    //             sys.OnUpdate();
    //         }
    //     }, cts.Token);
    //     task1.Start();
    //     var task2 = new Task(_ =>
    //     {
    //         Debug.Log($"ThreadID_Task2={Thread.CurrentThread.ManagedThreadId.ToString()}");
    //         // Thread.Sleep(5000);
    //     }, cts.Token);
    //     task2.Start();

    //     taskList = new Task[]{
    //         task1,
    //         task2,
    //         };


    //     factory.ContinueWhenAll(taskList, _ =>
    //         {
    //             Debug.Log("子线程完毕" + System.DateTime.Now.Second);
    //             _updateTask = true;
    //         }, cts.Token);
    // }

    public void OnUpdate()
    {

        // await UniTask.Yield();

        foreach (var sys in _allUpdateSystems)
        {
            sys.PreUpdate();
        }

        foreach (var sys in _allUpdateSystems)
        {
            sys.OnUpdate();
        }
        foreach (var sys in _allUpdateSystems)
        {
            sys.PostUpdate();
        }
    }

    /// <summary>
    /// This function is called every fixed framerate frame, if the MonoBehaviour is enabled.
    /// </summary>
    private void FixedUpdate()
    {
        foreach (var sys in _allFixUpdateSystems)
        {
            sys.PreFixUpdate();
        }

        foreach (var sys in _allFixUpdateSystems)
        {
            sys.OnFixUpdate();
        }
        foreach (var sys in _allFixUpdateSystems)
        {
            sys.PostFixUpdate();
        }

    }

    /// <summary>
    /// LateUpdate is called every frame, if the Behaviour is enabled.
    /// It is called after all Update functions have been called.
    /// </summary>
    private void LateUpdate()
    {
        foreach (var sys in _allLateUpdateSystems)
        {
            sys.PreLateUpdate();
        }

        foreach (var sys in _allLateUpdateSystems)
        {
            sys.OnLateUpdate();
        }
        foreach (var sys in _allLateUpdateSystems)
        {
            sys.PostLateUpdate();
        }
    }

}
