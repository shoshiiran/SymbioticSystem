using UnityEngine;
public static class GameObjectExtensions
{
    public static ActorBehaviour AddActorMono(this GameObject gameObject, ActorBehaviour Behaviour, WorldSystem worldSystem)
    {
        if (worldSystem == null) return Behaviour;

        var actorBehaviour = worldSystem.GetActorBehaviour(gameObject);
        if (actorBehaviour != null && actorBehaviour.GetType() == Behaviour.GetType()) return Behaviour;

        Behaviour.BindActor(gameObject, worldSystem);

        // foreach (var item in Behaviour.GetAllActorSystems())
        // {
        //     var sys = item as ActorSystem;
        //     sys.BindActor(gameObject);
        //     worldSystem.AddSystem(sys);
        // }
        return Behaviour;
    }

    public static bool RemoveActorMono(this GameObject gameObject, WorldSystem worldSystem)
    {
        if (worldSystem == null) return false;

        // WorldSystem.Instance.AddSystem(actorSystem);
        var actorBehaviour = worldSystem.GetActorBehaviour(gameObject);
        if (actorBehaviour == null)
        {
            return false;

        }
        actorBehaviour.UnbindActor(gameObject, worldSystem);

        return true;
    }
}