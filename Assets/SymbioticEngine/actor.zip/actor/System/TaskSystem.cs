using Cysharp.Threading.Tasks;
public abstract class TaskSystem : IInitInterface
{
    public abstract void OnDestroy();

    public abstract void OnStart();

    public virtual void OnPause()
    {

    }

    public virtual void OnResume()
    {

    }
}