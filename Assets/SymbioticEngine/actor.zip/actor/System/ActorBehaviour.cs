using System.Collections.Generic;
using UnityEngine;
public abstract class ActorBehaviour : IAcotrInterface
{
    public GameObject Actor
    {
        get; set;
    }
    bool IAcotrInterface.Enabled { get => Actor.activeSelf; }

    public void BindActor(GameObject go, WorldSystem worldSystem)
    {
        Actor = go;
        // worldSystem.AddSystem(_systems);
        InitBehaviour();

        foreach (var sys in _actorAllSystems)
        {
            sys.Actor = Actor;
            worldSystem.AddSystem(sys as ActorSystem);
        }
        worldSystem.AddBehaviours(this);
    }

    public void UnbindActor(GameObject go, WorldSystem worldSystem)
    {
        if (Actor == null) return;

        foreach (var sys in _actorAllSystems)
        {
            sys.Actor = Actor;
            worldSystem.RemoveSystem(sys as ActorSystem);
        }

        worldSystem.RemoveBehaviours(this);
        Actor = null;

    }


    /// <summary>
    /// 初始化，添加system
    /// </summary>
    public abstract void InitBehaviour();


    /// <summary>
    /// 获取actorBehaviours注册的所有system
    /// </summary>
    /// <returns></returns>
    public HashSet<IAcotrInterface> GetAllActorSystems()
    {
        return _actorAllSystems;
    }

    public void AddSystem(IAcotrInterface system)
    {
        _actorAllSystems.Add(system);
    }

    public void RemoveSystem(IAcotrInterface system)
    {
        _actorAllSystems.Remove(system);
    }

    readonly HashSet<IAcotrInterface> _actorAllSystems = new();
    readonly Dictionary<int, IAcotrInterface> _actorSystems = new();
}