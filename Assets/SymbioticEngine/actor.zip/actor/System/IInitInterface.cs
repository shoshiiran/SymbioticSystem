public interface IInitInterface
{
    void OnStart();
    // void OnPreUpdate();
    
    // void OnUpdate();

    // void OnLateUpdate();
    // void OnDestroy();
    // void OnPause();
    // void OnResume();
}