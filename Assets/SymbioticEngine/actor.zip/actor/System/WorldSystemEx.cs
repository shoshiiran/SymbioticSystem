using UnityEngine;
public static class WorldSystemEx
{

    public static ActorBehaviour GetActorBehaviour(this WorldSystem worldSystem, GameObject gameObject)
    {
        return worldSystem.GetActorBehaviour(gameObject);
    }
}