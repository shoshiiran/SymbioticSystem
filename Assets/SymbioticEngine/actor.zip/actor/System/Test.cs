using UnityEngine;
public class Test : ActorBehaviour
{
    public override void InitBehaviour()
    {
        Debug.Log("开始 --添加 movesystem" + System.DateTime.Now);
        AddSystem(new MoveSystem());
        Debug.Log("完成 --添加 movesystem" + System.DateTime.Now);
    }
}