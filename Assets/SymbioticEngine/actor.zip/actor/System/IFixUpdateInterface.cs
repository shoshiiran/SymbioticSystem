public interface IFixUpdateInterface
{
    void PreFixUpdate();
    void OnFixUpdate();
    void PostFixUpdate();
}