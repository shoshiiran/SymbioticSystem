using UnityEngine;

public interface IAcotrInterface
{
    GameObject Actor { get; set; }
    bool Enabled { get; }
}